public class Ex6_15
{
	public static void main(String[]args)
	{
		//no figure 6.2
	}
}